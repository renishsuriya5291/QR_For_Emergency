<!-- resources/views/welcome.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container w-50">
    <div class="full-height">
        
        <div class="container">
            <div class="container text-center">
                <h2>
                    <span class="text font-bold">
                        Sign In
                    </span>
                </h2>
            </div>
            
            <!-- Another section with buttons -->
            <div class="container mt-5">
                <div class="row justify-content-between">
                    <div class="col">
                        <a href="/auth/google" class="btn btn-outline-primary btn-block">Signin with Google</a>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-block">Signin with Facebook</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code\react\QR_For_Emergency\frontend_laravel\resources\views/pages/signin.blade.php ENDPATH**/ ?>