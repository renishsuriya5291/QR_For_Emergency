<!-- create_qr_form.blade.php -->

<div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="text" class="form-control" id="emailInput" placeholder="Enter Email Address of your member">
    </div>
    <button type="submit" onclick="submitAddMember()" class="btn btn-primary">Add Member</button>
</div>

<script>
    
</script>
