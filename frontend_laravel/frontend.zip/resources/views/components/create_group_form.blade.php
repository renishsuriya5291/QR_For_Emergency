<!-- create_qr_form.blade.php -->

<div>
    <div class="form-group">
        <label for="nameInput">Name</label>
        <input type="text" class="form-control" id="nameInput" placeholder="Enter your GroupName">
    </div>
    <button type="submit" onclick="submitGroup()" class="btn btn-primary">Create Group</button>
</div>

<script>
    
</script>
